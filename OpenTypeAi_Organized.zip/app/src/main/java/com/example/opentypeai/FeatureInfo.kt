package com.example.opentypeai

data class FeatureInfo(
    val tag: String,
    val name: String,
    val description: String
)